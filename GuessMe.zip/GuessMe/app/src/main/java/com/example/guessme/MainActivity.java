package com.example.guessme;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;


public class MainActivity extends AppCompatActivity {
    TextView tuser, tr, ta, tu;
    int randNum;
    int N=9999;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tuser = (EditText) findViewById(R.id.UserNum);
        /*final int N = 9999;*/
        Random rand = new Random();
        randNum = rand.nextInt(N);
    }

    public void check(View view) {
        //获取编辑框内容
        String guessStr = "";
        guessStr = tuser.getText().toString();
        if(guessStr.length()!=0){
            int guessNum = Integer.valueOf(guessStr);
            if (guessNum < randNum) {
                setContentView(R.layout.under);
                tu = (TextView) findViewById(R.id.Unum);
                tu.setText(guessStr);
            }
            else if(guessNum>randNum){
                setContentView(R.layout.above);
                ta = (TextView) findViewById(R.id.Anum);
                ta.setText(guessStr);
            }
            else if(guessNum==randNum){
                setContentView(R.layout.right);
                tr = (TextView) findViewById(R.id.Rnum);
                tr.setText(guessStr);
            }
        }
        else{
            Toast.makeText(this,"please enter a number",Toast.LENGTH_LONG).show();
        }

    }

    public void goback(View view) {
        setContentView(R.layout.activity_main);
        tuser = (EditText) findViewById(R.id.UserNum);
    }
    public void restart(View view){
        Random rand = new Random();
        randNum = rand.nextInt(N);
        setContentView(R.layout.activity_main);
        tuser = (EditText) findViewById(R.id.UserNum);
    }

}
